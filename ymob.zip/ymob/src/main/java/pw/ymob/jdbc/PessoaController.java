package pw.ymob.jdbc;


import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;


@WebServlet(value = "/ymob/pessoas")
public class PessoaController extends HttpServlet{
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
System.out.println("entrou controler");
		String op = request.getParameter("op");
		System.out.println("1");
		
		op = (op == null ? "" : op);
		Pessoa pessoa = new Pessoa();
		pessoa.setCodigo(request.getParameter("codigo"));
		pessoa.setNome(request.getParameter("nome"));
		pessoa.setEmail(request.getParameter("email"));
		pessoa.setCpfCnpj(request.getParameter("cpfCnpj"));
		pessoa.setEndereco(request.getParameter("endereco"));
		System.out.println("2");

		List<Pessoa> pessoas = null;
		try {
			if (op.equals("incluir")) {
				PessoaModel.incluir(pessoa);
			} else if (op.equals("salvar")) {
				PessoaModel.salvar(pessoa);
			} else if (op.equals("excluir")) {
				PessoaModel.excluir(pessoa);
			}
			pessoas = PessoaModel.listar();
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

		System.out.println("3");

	
		
	request.setAttribute("pessoas", pessoas);
	System.out.println("antes dispatcher!");
	
	request.getRequestDispatcher("ymob-jdbc/Pessoa-View.jsp");
	System.out.println("depois dispatcher!");
	
	}

	
}
