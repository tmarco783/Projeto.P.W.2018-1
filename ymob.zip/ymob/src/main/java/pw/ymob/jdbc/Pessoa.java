package pw.ymob.jdbc;

public class Pessoa {
	private String codigo;
	private String nome;
	private String email;
	private String cpfCnpj;
	private String endereco;

    public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}


	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}


	public String getCpfCnpj() {
		return cpfCnpj;
	}


	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}


	public String getEndereco() {
		return endereco;
	}


	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}




	  public boolean hasCodigo() {
	    return codigo != null && !codigo.trim().equals("");
	  }
	
	
	
	
	

	
	
	
	
}
