package aluguel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.ListView;

public class PessoaModel {
	//
	
	private static Connection obterConexao() throws SQLException {
		String url = "jdbc:derby://localhost:1527/aluguel;create=false";
		String user = "aluguel";
		String password = "aluguel";
		return DriverManager.getConnection(url,user,password);
	}
	
	public static void incluir(Pessoa pessoa) throws SQLException {
		Connection conn=obterConexao();
		
		String sql = "insert into aluguel (codigo,nome,email,cpfcnpj,endereco) values (?,?,?,?,?)";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, pessoa.getCodigo());
		pstmt.setString(2, pessoa.getNome());
		pstmt.setString(3, pessoa.getEmail());
		pstmt.setString(4, pessoa.getCpfCnpj());
		pstmt.setString(5, pessoa.getEndereco());
		pstmt.execute();
	}
	
	public static void salvar(Pessoa pessoa) throws SQLException {
		Connection conn=obterConexao();
		
		String sql = "update aluguel set codigo=?, nome=? ,email=?,cpfcnpj=?,endereco=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, pessoa.getCodigo());
		pstmt.setString(2, pessoa.getNome());
		pstmt.setString(3, pessoa.getEmail());
		pstmt.setString(4, pessoa.getCpfCnpj());
		pstmt.setString(5, pessoa.getEndereco());
		pstmt.execute();
	}
	
	public static List<Pessoa>  listar() throws SQLException {
		Connection conn=obterConexao();

		Statement stmt=conn.createStatement();
		String sql = "select codigo,nome,email,cpfcnpj,endereco from aluguel order by codigo";
		ResultSet rs = stmt.executeQuery(sql);
		List<Pessoa> listaDePessoas = new ArrayList<Pessoa>();
		while (rs.next()) {
			Pessoa pessoa = new Pessoa();
			pessoa.setCodigo(rs.getString("codigo"));
			pessoa.setNome(rs.getString("nome"));
			pessoa.setEmail(rs.getString("email"));
			pessoa.setCpfCnpj(rs.getString("cpfcnpj"));
			pessoa.setEndereco(rs.getString("endereco"));
			listaDePessoas.add(pessoa);
		}
		return listaDePessoas;
		
	}
	
	
	public static void excluir(Pessoa pessoa) throws SQLException {
		Connection conn=obterConexao();
		
		String sql = "delete from pessoas where codigo=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setString(1, pessoa.getCodigo());
		pstmt.execute();
	}
	
	
	
	
	
}
